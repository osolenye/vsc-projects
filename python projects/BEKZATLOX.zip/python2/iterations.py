import math

def f(x):
    return x + math.log(x)

def g(x):
    return -math.log(x)

x0 = 1
x = g(x0)
e = 0.001

while abs(x - x0) > e:
    x0 = x
    x = g(x0)

    print(f'x0: {x0}, x = {x}, f(x) = {f(x)}, f(x0) = {f(x0)}')


print("К великому сожалению моя функция решения этим методом не позволяет. Мне жаль")
